package app.model;

import java.io.File;
import java.util.ArrayList;

public class Model {
	private String nomeCartellaPrincipale;

	public ArrayList<String> getElencoCartelleUtente(){
		ArrayList<String> s=new ArrayList<String>();
		File cartella = new File("CartelleFileMp3/"+nomeCartellaPrincipale+"/");
		for(String nomeFile : cartella.list())
			s.add(nomeFile);
		return s;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public String getNomeCartellaPrincipale() {
		return nomeCartellaPrincipale;
	}

	public void setNomeCartellaPrincipale(String nomeCartellaPrincipale) {
		this.nomeCartellaPrincipale = nomeCartellaPrincipale;
	}
}
