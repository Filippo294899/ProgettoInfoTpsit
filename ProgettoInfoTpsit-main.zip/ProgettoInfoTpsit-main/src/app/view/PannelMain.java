package app.view;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;


import java.awt.BorderLayout;

import app.Thread.ThUpdate;
import app.controller.Controller;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.LayoutManager;

import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JList;


public class PannelMain extends JPanel {

	private static final long serialVersionUID = 1L;
	private Controller controller;
	private JFrame frame;
	private JPanel panelCartelleCanzoni;
	
	public PannelMain( Controller c , JFrame frame) {
		
		controller=c;
		this.frame=frame;
		frame.setBounds(100, 100, 600, 500);
		setBounds(100, 100, 600, 500);
		setLayout(null);
		
		controller.setCartellaPrincipale(controller.getElementoFileLogin(t-> t.equals("nome")));
		
		
		JLabel lblTitolo = new JLabel("Bentornato "+controller.getElementoFileLogin(t->t.equals("nome")));
		lblTitolo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTitolo.setBounds(205, 11, 209, 31);
		add(lblTitolo);
		
		JScrollPane scrollPaneCartelleUtente = new JScrollPane();
		scrollPaneCartelleUtente.setBounds(10, 40, 133, 425);
		add(scrollPaneCartelleUtente);
		
		JLabel lblCartelle = new JLabel("Cartelle Utente",SwingConstants.CENTER);
		lblCartelle.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrollPaneCartelleUtente.setColumnHeaderView(lblCartelle);
		
		panelCartelleCanzoni = new JPanel();
		panelCartelleCanzoni.setLayout((LayoutManager) new BoxLayout(panelCartelleCanzoni, BoxLayout.Y_AXIS));
		scrollPaneCartelleUtente.setViewportView(panelCartelleCanzoni);
		
		

	
		new ThUpdate(this).start();;
	}
	public void addCartelleUtenteButton() {
		if(controller.getElencoCartelleUtente()!=null)
			for(String s:controller.getElencoCartelleUtente()) {
				JButton btnNewButton = new JButton(s);
				panelCartelleCanzoni.add(btnNewButton,BorderLayout.CENTER);
			}
	}
	
	
	public void update() {
		addCartelleUtenteButton();
	}
}
